#!/bin/bash
rm WORK/*
rm e~testbench_md_mas_mc.o
rm e~testbench.o
rm resultado.ghw
rm testbench
rm testbench_md_mas_mc
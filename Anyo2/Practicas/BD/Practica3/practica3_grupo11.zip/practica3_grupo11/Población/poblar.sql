/*
    BASES DE DATOS
    Practica 3

    Fichero: poblar.sql

    Autores:    
        Alvaro Seral Gracia                     819425
        Cristian Andrei Selivanov Dobrisan      816456
        Dorian Boleslaw Wozniak                 817570

    Descripción:
        Sentencias SQL para poblar las tablas de la base de datos
*/

@aeropuerto;

@fabricante;

@modelo;

@avion;

@compania;

@vuelo;

@desvio;

commit;
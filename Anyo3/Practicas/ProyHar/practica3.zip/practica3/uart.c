#include "uart.h"

#include <LPC210X.h>
#include <inttypes.h>

enum {
    BUFSIZE = 16,
    
    PIN_0_0 = (0x3 << 0),
    PIN_0_1 = (0x2 << 0),
    
    PIN_1_0 = (0x3 << 1),
    PIN_1_1 = (0x2 << 1),
    
    
    LCR_8BIT = 0x03,
    LCR_DLAB = 0x80
};


void uart0_RSI (void) __irq {
    
}

void uart0_init() {
    PINSEL0 &= ~PIN_0_0;
    PINSEL0 |= PIN_0_1;
    PINSEL0 &= ~PIN_1_0;
    PINSEL0 |= PIN_1_1;
    
    U0LCR |= LCR_8BIT | LCR_DLAB;
    U0DLL = 97;
    U0LCR &= ~LCR_DLAB;
}

void uart0_enviar_array() {

}

void uart0_continuar_envio() {

}


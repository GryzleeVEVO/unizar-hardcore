#ifndef G_SERIE_H
#define G_SERIE_H

#endif // G_SERIE_H

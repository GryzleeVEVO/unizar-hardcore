/*
    Proyecto Hardware
    Práctica 2

    Fichero:
        tiempo.c

    Autores:
        Dorian Boleslaw Wozniak (817570@unizar.es)
        Pablo Latre Villacampa (778043@unizar.es)

    Descripción: 
        Implementación de métodos para inicializar y utilizar los timers timer0
        (encola un mensaje periodicamente) y timer1 (contador de tiempo en us)
*/

#include <LPC210X.h>

#include "tiempo.h"
#include "cola_eventos.h"
#include "irq_control.h"

// Constantes para registros de los timers
enum {
    // 60 MHz -> 1s     = 1 / (1/PCLK * 4)
    TIME_SEC    = 15000000,
    // 60 Mhz -> 1ms    = (10 ^-3) / (1/PCLK * 4)
    TIME_MS     = 15000 - 1,
    // 60 Mhz -> 1us    = (10 ^-6) / (1/PCLK * 4)
    TIME_US     = 15 - 1,
    
    // 60 MHz -> (PCLK / 32768) - 1,
    PREINT_60MHZ    = 1830,
    // 60 MHz -> (PCLK) - (32768 * (PREINT + 1)),
    PREFRAC_60MHZ   = 1792,
    
    MR0_INT     = 0x1,
    MR0_RESET   = 0x2,
    
    TCR_ENABLE  = 0x1,
    TCR_RESET   = 0x2,
    
    CCR_ENABLE  = 0x1,
    CCR_RESET   = 0x2,
    
    WD_ENABLE   = 0x1,
    WD_RESET    = 0x2
};


// Constantes para interrupciones vectorizadas
enum {
    POS_TIMER0 = 4, // Interrupción 4
    POS_TIMER1 = 5, // Interrupción 5
    
    INT_TIMER0 = (0x1 << POS_TIMER0),   // Bit 4
    INT_TIMER1 = (0x1 << POS_TIMER1),   // Bit 5
    
    VIC_CNTL_ENABLE = 0x20
};

// Cuenta de interrupciones
static volatile uint32_t timer0_count = 0;
static volatile uint32_t timer1_count = 0;

// Rutinas de servicio

// timer0 cuando haya vencido periodo ms
void timer0_RSI (void) __irq {
    // Trata la interrupción
    timer0_count++;
    cola_encolar_eventos(T0_PERIODO, timer0_count, 0);
    // Baja la interrupción
    T0IR = 1;
}

// timer1 cuando haya desbordado el TC
void timer1_RSI (void) __irq {
    // Trata la interrupción
    timer1_count++;
    // Evento encolado para efectos de depuración
    cola_encolar_eventos(T1_OVERFLOW, timer0_count, 0);
    // Baja la interrupción
    T1IR = 1;
    VICVectAddr = 0;
}

/*
    Pre: ---
    Post: timer1 mide tiempo con precisión de us, interrumpiendo cuando el 
            contador desborda. Queda asignado a VIC[1]
*/
void temporizador_iniciar() {
    // Ajusta la cuenta para contar en us e interrumpir cuando desborde
    T1PR = TIME_US;
    T1MR0 = 0xffffffff - 1;
    T1MCR |= MR0_INT | MR0_RESET;

    // Configura VIC[1] para tratar timer1
    VICVectAddr1 = (uint32_t) timer1_RSI;
    VICVectCntl1 |= VIC_CNTL_ENABLE | POS_TIMER1;
}

/*
    Pre: temporizador_iniciar()
    Post: Habilita interrupciones para timer1
*/
void temporizador_empezar() {
    // Reinicia la cuenta de interrupciones
    timer1_count = 0;

    // Reinicia y arranca TC
    T1TCR |= TCR_ENABLE | TCR_RESET;
    T1TCR &= ~TCR_RESET;

    // Habilita interrupciones para timer1 (bit 5)
    VICIntEnable |= INT_TIMER1;
}

/*
    Pre:  temporizador_empezar()
    Post: Devuelve el valor del contador de timer1
*/
uint32_t temporizador_leer() {
    // Lee tiempo actual
    uint32_t time = T1TC;
    
    // Añade las veces que se ha desbordado (cada ~71 min)
    // NOTA: Devuelve actualmente uint32_t, time quedará desbordado igualmente
    for (int i = timer1_count; i > 0; i--) time += 0xffffffff;

    return time;
}

/*
    Pre:  temporizador_empezar()
    Post: Devuelve el valor del contador de timer1 y deshabilta interrupciones 
            de timer1
*/
uint32_t temporizador_parar() {
    
    // Detiene timer
    T1TCR &= ~TCR_ENABLE;
    VICIntEnClr |= INT_TIMER1;

    return temporizador_leer();
}

/*
    Pre: ---
    Post: timer0 mide tiempo con precisión de ms, interrumpiendo cuando el 
            contador alcanza periodo ms. Queda asignado a VIC[0] y se habilitan
            interrupciones
*/
void temporizador_reloj(uint32_t periodo) {
    timer0_count = 0;

    // Ajusta la cuenta para contar ms e interrumpir cuando alcance periodo
    T0PR = TIME_MS;
    T0MR0 = periodo - 1;
    T0MCR |= MR0_INT | MR0_RESET;

    // Reinicia TC
    T0TCR |= TCR_ENABLE | TCR_RESET;
    T0TCR &= ~TCR_RESET;
    
    // Habilita FIQ
    VICIntSelect |= INT_TIMER0;
    VICIntEnable |= INT_TIMER0;
}

void RTC_init() {
    PREINT |= PREINT_60MHZ;
    PREFRAC |= PREFRAC_60MHZ;
    
    CCR |= CCR_ENABLE | CCR_RESET;
    CCR &= ~CCR_RESET;
}

void RTC_leer(uint8_t *min, uint8_t *seg) {
    *min = MIN;
    *seg = SEC;
}

void WD_init(uint32_t sec) {

    WDTC = TIME_SEC * sec;
    WDMOD = WD_ENABLE | WD_RESET;
    
    WD_feed();
}

void WD_feed() {
    uint8_t irq = read_IRQ_bit(), fiq = read_FIQ_bit();
    if (!irq) disable_irq_fiq();
    else if (!fiq) disable_fiq();
    
    WDFEED = 0xaa;
    WDFEED = 0x55;
        
    if (!irq) enable_irq_fiq();
    else if (!fiq) enable_fiq();
}

uint32_t __SWI_0 (void) {
    return temporizador_leer();
}

uint32_t __SWI_1 (void) {
    uint8_t min, seg;
    RTC_leer(&min, &seg);
    
    return 60 * min + seg;
}

#ifndef POWER_H
#define POWER_H

/*
    Coloca el procesador en modo reposo
*/
void power_idle(void);

/*
    Coloca el procesador en modo dormir
*/
void power_down(void);

#endif // POWER_H

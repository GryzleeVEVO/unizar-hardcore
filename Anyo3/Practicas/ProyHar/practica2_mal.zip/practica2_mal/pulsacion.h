enum {
	PULSADO = 0,
	NO_PULSADO = 1
};

unsigned int nueva_pulsacion_0(void);
void clear_nueva_pulsacion_0(void);
void actualizar_estado_0(void);
unsigned int leer_estado_0(void);


#include "conecta4_2022.h"
#include "entrada.h"

// MAIN
int main(void)
{
	// inicializar sistema
	//... practica 2

	// jugar
	conecta4_jugar();

	while (1)
		; // no hay S.O., no se retorna
}

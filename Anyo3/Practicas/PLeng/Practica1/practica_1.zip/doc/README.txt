Compilador clike.jar
------------------------------
Análisis léxico y sintáctico

Autor: Wozniak, Dorian Boleslaw  (817570@unizar.es)


Invocar como:

-------------------------------------------------------------
java -jar clike.jar <fichero_fuente_clike>
-------------------------------------------------------------

Si se invoca sin parámetros, lee la entrada estándar.

El programa se ha probado con la batería de programas de test dada y todas
son analizadas sin errores. 